import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

type JsonObject = Record<string, unknown>;

const ALLOWED_EVENT_TYPES = new Set([
  "meal",
  "workout",
  "weigh_in",
  "recovery",
  "sleep",
  "note",
  "social_event",
  "alcohol",
  "symptom",
]);

const ALLOWED_CHANGE_FIELDS = new Set([
  "event_type",
  "title",
  "description",
  "occurred_date",
  "occurred_time",
  "source_text_span",
  "facts",
  "estimates",
  "interpretations",
  "extraction_confidence",
  "estimate_confidence",
  "needs_review",
]);

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-action-secret",
  "Access-Control-Allow-Methods": "POST, PATCH, OPTIONS",
};

function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body, null, 2), {
    status,
    headers: {
      ...corsHeaders,
      "Content-Type": "application/json",
    },
  });
}

function errorResponse(
  error: string,
  code: string,
  details: JsonObject = {},
  status = 400,
): Response {
  return jsonResponse({ ok: false, error, code, details }, status);
}

function isPlainObject(value: unknown): value is JsonObject {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function isValidIsoDate(value: unknown): boolean {
  return typeof value === "string" && /^\d{4}-\d{2}-\d{2}$/.test(value);
}

function isValidTimeOrNull(value: unknown): boolean {
  return value === null || (typeof value === "string" && /^\d{2}:\d{2}(:\d{2})?$/.test(value));
}

function isValidUuid(value: unknown): boolean {
  return typeof value === "string" &&
    /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
}

function isValidConfidence(value: unknown): boolean {
  return value === null ||
    (typeof value === "number" && Number.isFinite(value) && value >= 0 && value <= 1);
}

function cleanObject<T extends JsonObject>(obj: T): Partial<T> {
  const result: Partial<T> = {};
  for (const [key, value] of Object.entries(obj)) {
    if (value !== undefined) {
      (result as JsonObject)[key] = value;
    }
  }
  return result;
}

function validateChanges(changes: unknown): { ok: true; value: JsonObject } | { ok: false; error: string; details: JsonObject } {
  if (!isPlainObject(changes)) {
    return { ok: false, error: "changes must be an object", details: {} };
  }

  const keys = Object.keys(changes);
  if (keys.length === 0) {
    return { ok: false, error: "changes must include at least one field", details: {} };
  }

  const invalidFields = keys.filter((key) => !ALLOWED_CHANGE_FIELDS.has(key));
  if (invalidFields.length > 0) {
    return {
      ok: false,
      error: "changes includes fields that are not allowed",
      details: { invalid_fields: invalidFields, allowed_fields: Array.from(ALLOWED_CHANGE_FIELDS) },
    };
  }

  if ("event_type" in changes) {
    if (typeof changes.event_type !== "string" || !ALLOWED_EVENT_TYPES.has(changes.event_type)) {
      return {
        ok: false,
        error: "Invalid event_type",
        details: { event_type: changes.event_type, allowed_event_types: Array.from(ALLOWED_EVENT_TYPES) },
      };
    }
  }

  for (const field of ["title", "description", "source_text_span"]) {
    if (field in changes && changes[field] !== null && typeof changes[field] !== "string") {
      return { ok: false, error: `${field} must be a string or null`, details: { field } };
    }
  }

  if ("description" in changes && typeof changes.description === "string" && changes.description.trim().length === 0) {
    return { ok: false, error: "description cannot be empty", details: {} };
  }

  if ("occurred_date" in changes && changes.occurred_date !== null && !isValidIsoDate(changes.occurred_date)) {
    return { ok: false, error: "occurred_date must be YYYY-MM-DD or null", details: { occurred_date: changes.occurred_date } };
  }

  if ("occurred_time" in changes && !isValidTimeOrNull(changes.occurred_time)) {
    return { ok: false, error: "occurred_time must be HH:MM, HH:MM:SS, or null", details: { occurred_time: changes.occurred_time } };
  }

  for (const field of ["facts", "estimates", "interpretations"]) {
    if (field in changes && !isPlainObject(changes[field])) {
      return { ok: false, error: `${field} must be an object`, details: { field } };
    }
  }

  for (const field of ["extraction_confidence", "estimate_confidence"]) {
    if (field in changes && !isValidConfidence(changes[field])) {
      return { ok: false, error: `${field} must be null or a number from 0 to 1`, details: { field, value: changes[field] } };
    }
  }

  if ("needs_review" in changes && typeof changes.needs_review !== "boolean") {
    return { ok: false, error: "needs_review must be boolean", details: { needs_review: changes.needs_review } };
  }

  return { ok: true, value: changes };
}

async function authorize(req: Request): Promise<Response | null> {
  const expectedSecret = Deno.env.get("ACTION_API_SECRET");
  if (!expectedSecret) {
    return errorResponse("Server is missing ACTION_API_SECRET", "SERVER_CONFIG_ERROR", {}, 500);
  }

  const actionSecretHeader =
    req.headers.get("X-Action-Secret") ??
    req.headers.get("x-action-secret") ??
    "";

  const authHeader = req.headers.get("Authorization") ?? "";
  const bearerSecret = authHeader.replace(/^Bearer\s+/i, "").trim();

  const providedSecret = actionSecretHeader.trim() || bearerSecret;

  if (!providedSecret || providedSecret !== expectedSecret) {
    return errorResponse("Unauthorized", "UNAUTHORIZED", {}, 401);
  }

  return null;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  if (req.method !== "POST" && req.method !== "PATCH") {
    return errorResponse("Method not allowed", "METHOD_NOT_ALLOWED", { method: req.method }, 405);
  }

  const authError = await authorize(req);
  if (authError) return authError;

  let payload: JsonObject;
  try {
    payload = await req.json();
  } catch (_err) {
    return errorResponse("Invalid JSON", "INVALID_JSON", {}, 400);
  }

  const eventId = payload.event_id;
  if (!isValidUuid(eventId)) {
    return errorResponse("event_id must be a valid UUID", "MISSING_OR_INVALID_EVENT_ID", { event_id: eventId }, 400);
  }

  const validation = validateChanges(payload.changes);
  if (!validation.ok) {
    return errorResponse(validation.error, "VALIDATION_ERROR", validation.details, 400);
  }

  if ("change_reason" in payload && payload.change_reason !== null && typeof payload.change_reason !== "string") {
    return errorResponse("change_reason must be a string or null", "VALIDATION_ERROR", { change_reason: payload.change_reason }, 400);
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const serviceRoleKey = Deno.env.get("SERVICE_ROLE_KEY");

  if (!supabaseUrl || !serviceRoleKey) {
    return errorResponse("Server is missing Supabase configuration", "SERVER_CONFIG_ERROR", {
      has_SUPABASE_URL: Boolean(supabaseUrl),
      has_SERVICE_ROLE_KEY: Boolean(serviceRoleKey),
    }, 500);
  }

  const supabase = createClient(supabaseUrl, serviceRoleKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });

  const { data: existingEvent, error: fetchError } = await supabase
    .from("fitness_events")
    .select("id, facts, estimates, interpretations")
    .eq("id", eventId)
    .maybeSingle();

  if (fetchError) {
    return errorResponse("Database error while fetching event", "DATABASE_ERROR", { message: fetchError.message }, 500);
  }

  if (!existingEvent) {
    return errorResponse("Event not found", "EVENT_NOT_FOUND", { event_id: eventId }, 404);
  }

  const changes = validation.value;
  const updatePayload: JsonObject = {};

  for (const [key, value] of Object.entries(changes)) {
    if (["facts", "estimates", "interpretations"].includes(key)) {
      const existingObject = isPlainObject((existingEvent as JsonObject)[key])
        ? ((existingEvent as JsonObject)[key] as JsonObject)
        : {};
      updatePayload[key] = { ...existingObject, ...(value as JsonObject) };
    } else {
      updatePayload[key] = value;
    }
  }

  const cleanedPayload = cleanObject(updatePayload);
  const updatedFields = Object.keys(cleanedPayload);

  const { data: updatedEvent, error: updateError } = await supabase
    .from("fitness_events")
    .update(cleanedPayload)
    .eq("id", eventId)
    .select("id, log_entry_id, event_type, title, description, occurred_date, occurred_time, source_text_span, facts, estimates, interpretations, extraction_confidence, estimate_confidence, needs_review, created_at, updated_at")
    .single();

  if (updateError) {
    return errorResponse("Database error while updating event", "DATABASE_ERROR", { message: updateError.message }, 500);
  }

  return jsonResponse({
    ok: true,
    data: {
      event_id: eventId,
      updated_fields: updatedFields,
      change_reason: payload.change_reason ?? null,
      event: updatedEvent,
    },
    event_id: eventId,
    updated_fields: updatedFields,
  });
});
