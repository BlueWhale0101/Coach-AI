import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

type JsonObject = Record<string, unknown>;

const ALLOWED_METRICS = [
  "bodyweight",
  "calories",
  "protein",
  "workouts",
  "training_load",
  "recovery",
  "sleep",
  "hunger",
  "energy",
] as const;

const ALLOWED_BUCKETS = ["day", "week"] as const;

const ALLOWED_EVENT_TYPES = [
  "meal",
  "workout",
  "weigh_in",
  "recovery",
  "sleep",
  "note",
  "social_event",
  "alcohol",
  "symptom",
] as const;

function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body, null, 2), {
    status,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-action-secret",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
    },
  });
}

function errorResponse(error: string, code: string, details: JsonObject = {}, status = 400) {
  return jsonResponse({ ok: false, error, code, details }, status);
}

function isIsoDate(value: unknown): value is string {
  return typeof value === "string" && /^\d{4}-\d{2}-\d{2}$/.test(value);
}

function isAllowed(value: unknown, allowed: readonly string[]): value is string {
  return typeof value === "string" && allowed.includes(value);
}

function getNumber(obj: JsonObject | null | undefined, key: string): number | null {
  if (!obj) return null;
  const value = obj[key];
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value.trim() !== "" && Number.isFinite(Number(value))) return Number(value);
  return null;
}

function getString(obj: JsonObject | null | undefined, key: string): string | null {
  if (!obj) return null;
  const value = obj[key];
  if (typeof value === "string" && value.trim() !== "") return value.trim();
  return null;
}

function toDate(value: string): Date {
  return new Date(`${value}T00:00:00.000Z`);
}

function isoDate(date: Date): string {
  return date.toISOString().slice(0, 10);
}

function addDays(date: Date, days: number): Date {
  const out = new Date(date);
  out.setUTCDate(out.getUTCDate() + days);
  return out;
}

function daysInclusive(startDate: string, endDate: string): string[] {
  const start = toDate(startDate);
  const end = toDate(endDate);
  const days: string[] = [];

  for (let d = start; d <= end; d = addDays(d, 1)) {
    days.push(isoDate(d));
  }

  return days;
}

function weekStartMonday(dateString: string): string {
  const d = toDate(dateString);
  const day = d.getUTCDay(); // Sun 0, Mon 1
  const diff = day === 0 ? -6 : 1 - day;
  return isoDate(addDays(d, diff));
}

function loadRank(value: string | null): number | null {
  if (!value) return null;
  const normalized = value === "max_effort" ? "very_hard" : value;
  const ranks: Record<string, number> = {
    rest: 0,
    light: 1,
    moderate: 2,
    hard: 3,
    very_hard: 4,
  };
  return ranks[normalized] ?? null;
}

function rankToLoad(rank: number | null): string | null {
  if (rank === null) return null;
  if (rank <= 0) return "rest";
  if (rank === 1) return "light";
  if (rank === 2) return "moderate";
  if (rank === 3) return "hard";
  return "very_hard";
}

function levelRank(value: string | null): number | null {
  if (!value) return null;
  const ranks: Record<string, number> = {
    none: 0,
    low: 1,
    very_low: 1,
    mild: 1,
    normal: 2,
    okay: 2,
    moderate: 2,
    high: 3,
    very_high: 4,
    poor: 1,
    good: 3,
    excellent: 4,
  };
  return ranks[value] ?? null;
}

function rankToEnergy(rank: number | null): string | null {
  if (rank === null) return null;
  if (rank <= 1) return "low";
  if (rank === 2) return "normal";
  if (rank === 3) return "high";
  return "very_high";
}

function rankToHunger(rank: number | null): string | null {
  if (rank === null) return null;
  if (rank <= 1) return "low";
  if (rank === 2) return "normal";
  if (rank === 3) return "high";
  return "very_high";
}

function rankToSleepQuality(rank: number | null): string | null {
  if (rank === null) return null;
  if (rank <= 1) return "poor";
  if (rank === 2) return "okay";
  if (rank === 3) return "good";
  return "excellent";
}

function maxNonNull(values: Array<number | null>): number | null {
  const nums = values.filter((v): v is number => typeof v === "number" && Number.isFinite(v));
  return nums.length ? Math.max(...nums) : null;
}

function avg(values: number[]): number | null {
  if (!values.length) return null;
  return values.reduce((a, b) => a + b, 0) / values.length;
}

function pushPoint(points: JsonObject[], point: JsonObject, includeRaw: boolean) {
  if (!includeRaw) {
    delete point.raw_text;
    delete point.source_text_span;
    delete point.description;
  }
  points.push(point);
}

function summarizeDescriptions(prefix: string, descriptions: string[]): string | null {
  const clean = descriptions.map((d) => d.trim()).filter(Boolean);
  if (clean.length === 0) return null;
  return `${prefix}: ${clean.join(" | ")}`;
}

function pushUnique<T>(arr: T[], value: T | null | undefined) {
  if (value === null || value === undefined) return;
  if (!arr.includes(value)) arr.push(value);
}

function maxTrainingLoad(values: string[]): string | null {
  let bestRank = -1;
  let best: string | null = null;
  for (const raw of values) {
    const rank = loadRank(raw);
    if (rank !== null && rank > bestRank) {
      bestRank = rank;
      best = raw === "max_effort" ? "very_hard" : raw;
    }
  }
  return best;
}

async function generateDailySummary(supabase: ReturnType<typeof createClient>, date: string) {
  const { data: events, error: eventError } = await supabase
    .from("fitness_events")
    .select("id, log_entry_id, occurred_date, occurred_time, event_type, title, description, source_text_span, facts, estimates, interpretations, extraction_confidence, estimate_confidence, needs_review, created_at, updated_at")
    .eq("occurred_date", date)
    .order("occurred_time", { ascending: true, nullsFirst: true })
    .order("created_at", { ascending: true });

  if (eventError) {
    throw new Error(eventError.message);
  }

  const rows = events ?? [];
  const sourceLogEntryIds: string[] = [];
  const sourceFitnessEventIds: string[] = [];

  let bodyweightValue: number | null = null;
  let bodyweightUnit: string | null = null;

  let caloriesLow = 0;
  let caloriesHigh = 0;
  let hasCalories = false;

  let proteinLow = 0;
  let proteinHigh = 0;
  let hasProtein = false;

  let workoutCount = 0;
  const workoutDescriptions: string[] = [];
  const trainingLoadCandidates: string[] = [];
  const recoveryDescriptions: string[] = [];
  const sleepDescriptions: string[] = [];
  const flags: string[] = [];
  let needsReview = false;

  for (const event of rows) {
    pushUnique(sourceFitnessEventIds, event.id);
    pushUnique(sourceLogEntryIds, event.log_entry_id);

    const facts = (event.facts ?? {}) as JsonObject;
    const estimates = (event.estimates ?? {}) as JsonObject;

    if (event.needs_review) {
      needsReview = true;
      pushUnique(flags, "needs_review");
    }

    const calLow = getNumber(estimates, "calories_low");
    const calHigh = getNumber(estimates, "calories_high");
    if (calLow !== null || calHigh !== null) {
      hasCalories = true;
      caloriesLow += calLow ?? calHigh ?? 0;
      caloriesHigh += calHigh ?? calLow ?? 0;
    }

    const protLow = getNumber(estimates, "protein_g_low");
    const protHigh = getNumber(estimates, "protein_g_high");
    if (protLow !== null || protHigh !== null) {
      hasProtein = true;
      proteinLow += protLow ?? protHigh ?? 0;
      proteinHigh += protHigh ?? protLow ?? 0;
    }

    if (event.event_type === "weigh_in") {
      const weight = getNumber(facts, "weight_value");
      const unit = getString(facts, "weight_unit");
      if (weight !== null) {
        bodyweightValue = weight;
        bodyweightUnit = unit ?? "lb";
      }
    }

    if (event.event_type === "workout") {
      workoutCount += 1;
      workoutDescriptions.push(event.description);
      const estimatedLoad = getString(estimates, "training_load");
      const intensity = getString(facts, "intensity_reported");
      if (estimatedLoad) trainingLoadCandidates.push(estimatedLoad);
      if (intensity) trainingLoadCandidates.push(intensity);
    }

    if (event.event_type === "recovery") {
      recoveryDescriptions.push(event.description);

      const energy = getString(facts, "energy_level");
      const hunger = getString(facts, "hunger_level");
      const fatigue = getString(facts, "fatigue_level");
      const soreness = getString(facts, "soreness_level");

      if (energy === "low" || energy === "very_low") pushUnique(flags, "low_energy");
      if (hunger === "high" || hunger === "very_high") pushUnique(flags, "high_hunger");
      if (fatigue === "high" || fatigue === "very_high") pushUnique(flags, "fatigue");
      if (soreness === "high" || soreness === "very_high") pushUnique(flags, "high_soreness");
    }

    if (event.event_type === "sleep") {
      sleepDescriptions.push(event.description);
      const sleepQuality = getString(facts, "sleep_quality");
      if (sleepQuality === "poor") pushUnique(flags, "poor_sleep");
    }

    if (event.event_type === "alcohol") pushUnique(flags, "alcohol");
    if (event.event_type === "social_event") pushUnique(flags, "social_event");
    if (event.event_type === "symptom") pushUnique(flags, "symptom");
  }

  const trainingLoad = maxTrainingLoad(trainingLoadCandidates);
  if (trainingLoad === "hard") pushUnique(flags, "hard_training_day");
  if (trainingLoad === "very_hard") pushUnique(flags, "very_hard_training_day");

  const summary = {
    summary_date: date,
    bodyweight_value: bodyweightValue,
    bodyweight_unit: bodyweightUnit,
    calories_low: hasCalories ? Math.round(caloriesLow) : null,
    calories_high: hasCalories ? Math.round(caloriesHigh) : null,
    protein_g_low: hasProtein ? Math.round(proteinLow) : null,
    protein_g_high: hasProtein ? Math.round(proteinHigh) : null,
    workout_count: workoutCount,
    workout_summary: summarizeDescriptions("Workouts", workoutDescriptions),
    training_load: trainingLoad,
    recovery_summary: summarizeDescriptions("Recovery", recoveryDescriptions),
    sleep_summary: summarizeDescriptions("Sleep", sleepDescriptions),
    coach_summary: null,
    flags,
    source_log_entry_ids: sourceLogEntryIds,
    source_fitness_event_ids: sourceFitnessEventIds,
    generated_by: "get_trends_v0.1",
    needs_review: needsReview,
  };

  const { data: upserted, error: upsertError } = await supabase
    .from("daily_summaries")
    .upsert(summary, { onConflict: "summary_date" })
    .select("*")
    .single();

  if (upsertError) {
    throw new Error(upsertError.message);
  }

  return upserted;
}

async function ensureDailySummaries(supabase: ReturnType<typeof createClient>, startDate: string, endDate: string) {
  const dates = daysInclusive(startDate, endDate);

  // Keep v0.1 bounded to avoid accidentally doing large maintenance jobs.
  if (dates.length > 120) {
    throw new Error("Date range too large for summary-backed metric. Maximum is 120 days.");
  }

  const summaries = [];
  for (const date of dates) {
    summaries.push(await generateDailySummary(supabase, date));
  }

  return summaries;
}

function bucketDailyPoints(points: JsonObject[], metric: string, bucket: string): JsonObject[] {
  if (bucket === "day") return points;

  const groups = new Map<string, JsonObject[]>();
  for (const point of points) {
    const date = String(point.date ?? "");
    const key = weekStartMonday(date);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key)!.push(point);
  }

  const out: JsonObject[] = [];
  for (const [weekStart, group] of groups.entries()) {
    if (metric === "bodyweight") {
      const values = group.map((p) => Number(p.value)).filter((v) => Number.isFinite(v));
      out.push({
        week_start: weekStart,
        bucket: "week",
        value_avg: avg(values),
        value_first: values[0] ?? null,
        value_last: values.length ? values[values.length - 1] : null,
        count: values.length,
      });
      continue;
    }

    if (metric === "calories" || metric === "protein") {
      const lowVals = group.map((p) => Number(p.low)).filter((v) => Number.isFinite(v));
      const highVals = group.map((p) => Number(p.high)).filter((v) => Number.isFinite(v));
      out.push({
        week_start: weekStart,
        bucket: "week",
        low_sum: lowVals.reduce((a, b) => a + b, 0),
        high_sum: highVals.reduce((a, b) => a + b, 0),
        low_avg: avg(lowVals),
        high_avg: avg(highVals),
        count: group.length,
      });
      continue;
    }

    if (metric === "workouts") {
      const counts = group.map((p) => Number(p.count)).filter((v) => Number.isFinite(v));
      out.push({
        week_start: weekStart,
        bucket: "week",
        count: counts.reduce((a, b) => a + b, 0),
        day_count: group.length,
      });
      continue;
    }

    if (metric === "training_load") {
      const maxRank = maxNonNull(group.map((p) => loadRank(String(p.training_load ?? ""))));
      out.push({
        week_start: weekStart,
        bucket: "week",
        training_load_max: rankToLoad(maxRank),
        count: group.length,
      });
      continue;
    }

    if (metric === "energy") {
      const maxRank = maxNonNull(group.map((p) => levelRank(String(p.energy_level ?? ""))));
      out.push({
        week_start: weekStart,
        bucket: "week",
        energy_level_worst_or_highest_signal: rankToEnergy(maxRank),
        count: group.length,
      });
      continue;
    }

    if (metric === "hunger") {
      const maxRank = maxNonNull(group.map((p) => levelRank(String(p.hunger_level ?? ""))));
      out.push({
        week_start: weekStart,
        bucket: "week",
        hunger_level_max: rankToHunger(maxRank),
        count: group.length,
      });
      continue;
    }

    if (metric === "sleep") {
      const maxRank = maxNonNull(group.map((p) => levelRank(String(p.sleep_quality ?? ""))));
      out.push({
        week_start: weekStart,
        bucket: "week",
        sleep_quality_best_recorded: rankToSleepQuality(maxRank),
        count: group.length,
      });
      continue;
    }

    out.push({
      week_start: weekStart,
      bucket: "week",
      count: group.length,
    });
  }

  return out.sort((a, b) => String(a.week_start).localeCompare(String(b.week_start)));
}

serve(async (req) => {
  if (req.method === "OPTIONS") return jsonResponse({ ok: true });
  if (req.method !== "POST") return errorResponse("Method not allowed", "METHOD_NOT_ALLOWED", {}, 405);

  const expectedSecret = Deno.env.get("ACTION_API_SECRET");
  if (!expectedSecret) return errorResponse("Server is missing ACTION_API_SECRET", "SERVER_CONFIG_ERROR", {}, 500);

  const actionSecretHeader = req.headers.get("X-Action-Secret") ?? req.headers.get("x-action-secret") ?? "";
  const authHeader = req.headers.get("Authorization") ?? "";
  const bearerSecret = authHeader.replace(/^Bearer\s+/i, "").trim();
  const providedSecret = actionSecretHeader.trim() || bearerSecret;

  if (!providedSecret || providedSecret !== expectedSecret) {
    return errorResponse("Unauthorized", "UNAUTHORIZED", {}, 401);
  }

  let body: JsonObject;
  try {
    body = await req.json();
  } catch (_err) {
    return errorResponse("Invalid JSON body", "INVALID_JSON");
  }

  const metric = body.metric;
  const startDate = body.start_date;
  const endDate = body.end_date;
  const bucket = (body.bucket ?? "day") as string;
  const includeRaw = body.include_raw === true;
  const limit = Number(body.limit ?? 100);
  const offset = Number(body.offset ?? 0);
  const eventType = body.event_type;
  const query = typeof body.query === "string" && body.query.trim() ? body.query.trim().toLowerCase() : null;

  if (!isAllowed(metric, ALLOWED_METRICS)) {
    return errorResponse("Invalid metric", "INVALID_METRIC", { metric, allowed_metrics: ALLOWED_METRICS });
  }

  if (!isIsoDate(startDate) || !isIsoDate(endDate)) {
    return errorResponse("start_date and end_date must be ISO date strings YYYY-MM-DD", "INVALID_DATE");
  }

  if (endDate < startDate) {
    return errorResponse("end_date must be greater than or equal to start_date", "INVALID_DATE_RANGE");
  }

  if (!isAllowed(bucket, ALLOWED_BUCKETS)) {
    return errorResponse("Invalid bucket", "INVALID_BUCKET", { bucket, allowed_buckets: ALLOWED_BUCKETS });
  }

  if (typeof eventType !== "undefined" && eventType !== null && eventType !== "" && !isAllowed(eventType, ALLOWED_EVENT_TYPES)) {
    return errorResponse("Invalid event_type", "INVALID_EVENT_TYPE", { event_type: eventType, allowed_event_types: ALLOWED_EVENT_TYPES });
  }

  if (!Number.isInteger(limit) || limit < 1 || limit > 500) {
    return errorResponse("limit must be an integer between 1 and 500", "LIMIT_INVALID", { limit });
  }

  if (!Number.isInteger(offset) || offset < 0) {
    return errorResponse("offset must be an integer >= 0", "OFFSET_INVALID", { offset });
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const serviceRoleKey = Deno.env.get("SERVICE_ROLE_KEY");
  if (!supabaseUrl || !serviceRoleKey) {
    return errorResponse("Server is missing Supabase configuration", "SERVER_CONFIG_ERROR", {}, 500);
  }

  const supabase = createClient(supabaseUrl, serviceRoleKey, { auth: { persistSession: false } });

  try {
    let unit: string | null = null;
    let points: JsonObject[] = [];
    let source = "fitness_events";
    let summaries_generated = false;

    if (metric === "bodyweight") {
      let queryBuilder = supabase
        .from("fitness_events")
        .select("id, occurred_date, occurred_time, description, source_text_span, facts, log_entry_id")
        .eq("event_type", "weigh_in")
        .gte("occurred_date", startDate)
        .lte("occurred_date", endDate)
        .order("occurred_date", { ascending: true })
        .order("created_at", { ascending: true });

      const { data, error } = await queryBuilder;
      if (error) throw new Error(error.message);

      for (const event of data ?? []) {
        const facts = (event.facts ?? {}) as JsonObject;
        const value = getNumber(facts, "weight_value");
        const eventUnit = getString(facts, "weight_unit") ?? "lb";
        if (value === null) continue;
        unit = unit ?? eventUnit;
        pushPoint(points, {
          date: event.occurred_date,
          value,
          unit: eventUnit,
          source_event_id: event.id,
          log_entry_id: event.log_entry_id,
          description: event.description,
          source_text_span: event.source_text_span,
        }, includeRaw);
      }
    }

    if (["calories", "protein", "workouts", "training_load"].includes(metric as string)) {
      source = "daily_summaries";
      const summaries = await ensureDailySummaries(supabase, startDate, endDate);
      summaries_generated = true;

      for (const summary of summaries) {
        if (metric === "calories") {
          if (summary.calories_low === null && summary.calories_high === null) continue;
          unit = "kcal";
          points.push({
            date: summary.summary_date,
            low: summary.calories_low,
            high: summary.calories_high,
            source: "daily_summary",
            summary_id: summary.id,
          });
        }

        if (metric === "protein") {
          if (summary.protein_g_low === null && summary.protein_g_high === null) continue;
          unit = "g";
          points.push({
            date: summary.summary_date,
            low: summary.protein_g_low,
            high: summary.protein_g_high,
            source: "daily_summary",
            summary_id: summary.id,
          });
        }

        if (metric === "workouts") {
          if (!summary.workout_count) continue;
          points.push({
            date: summary.summary_date,
            count: summary.workout_count,
            summary: summary.workout_summary,
            training_load: summary.training_load,
            source: "daily_summary",
            summary_id: summary.id,
          });
        }

        if (metric === "training_load") {
          if (!summary.training_load) continue;
          points.push({
            date: summary.summary_date,
            training_load: summary.training_load,
            training_load_rank: loadRank(summary.training_load),
            workout_count: summary.workout_count,
            source: "daily_summary",
            summary_id: summary.id,
          });
        }
      }
    }

    if (["recovery", "energy", "hunger"].includes(metric as string)) {
      source = "fitness_events";
      let queryBuilder = supabase
        .from("fitness_events")
        .select("id, occurred_date, occurred_time, event_type, title, description, source_text_span, facts, estimates, log_entry_id")
        .eq("event_type", "recovery")
        .gte("occurred_date", startDate)
        .lte("occurred_date", endDate)
        .order("occurred_date", { ascending: true })
        .order("created_at", { ascending: true });

      const { data, error } = await queryBuilder;
      if (error) throw new Error(error.message);

      for (const event of data ?? []) {
        const facts = (event.facts ?? {}) as JsonObject;

        if (query) {
          const haystack = JSON.stringify(event).toLowerCase();
          if (!haystack.includes(query)) continue;
        }

        if (metric === "energy") {
          const energy = getString(facts, "energy_level");
          if (!energy) continue;
          pushPoint(points, {
            date: event.occurred_date,
            energy_level: energy,
            energy_rank: levelRank(energy),
            source_event_id: event.id,
            log_entry_id: event.log_entry_id,
            description: event.description,
            source_text_span: event.source_text_span,
          }, includeRaw);
        }

        if (metric === "hunger") {
          const hunger = getString(facts, "hunger_level");
          if (!hunger) continue;
          pushPoint(points, {
            date: event.occurred_date,
            hunger_level: hunger,
            hunger_rank: levelRank(hunger),
            source_event_id: event.id,
            log_entry_id: event.log_entry_id,
            description: event.description,
            source_text_span: event.source_text_span,
          }, includeRaw);
        }

        if (metric === "recovery") {
          pushPoint(points, {
            date: event.occurred_date,
            energy_level: getString(facts, "energy_level"),
            hunger_level: getString(facts, "hunger_level"),
            fatigue_level: getString(facts, "fatigue_level"),
            soreness_level: getString(facts, "soreness_level"),
            source_event_id: event.id,
            log_entry_id: event.log_entry_id,
            description: event.description,
            source_text_span: event.source_text_span,
          }, includeRaw);
        }
      }
    }

    if (metric === "sleep") {
      source = "fitness_events";
      const { data, error } = await supabase
        .from("fitness_events")
        .select("id, occurred_date, occurred_time, event_type, title, description, source_text_span, facts, estimates, log_entry_id")
        .eq("event_type", "sleep")
        .gte("occurred_date", startDate)
        .lte("occurred_date", endDate)
        .order("occurred_date", { ascending: true })
        .order("created_at", { ascending: true });

      if (error) throw new Error(error.message);

      for (const event of data ?? []) {
        const facts = (event.facts ?? {}) as JsonObject;
        const estimates = (event.estimates ?? {}) as JsonObject;

        pushPoint(points, {
          date: event.occurred_date,
          sleep_quality: getString(facts, "sleep_quality"),
          sleep_quality_rank: levelRank(getString(facts, "sleep_quality")),
          sleep_duration_hours: getNumber(facts, "sleep_duration_hours"),
          sleep_duration_hours_low: getNumber(estimates, "sleep_duration_hours_low"),
          sleep_duration_hours_high: getNumber(estimates, "sleep_duration_hours_high"),
          wake_count: getNumber(facts, "wake_count"),
          source_event_id: event.id,
          log_entry_id: event.log_entry_id,
          description: event.description,
          source_text_span: event.source_text_span,
        }, includeRaw);
      }
    }

    if (bucket === "week") {
      points = bucketDailyPoints(points, metric as string, bucket);
    }

    const totalBeforePaging = points.length;
    const paged = points.slice(offset, offset + limit);

    return jsonResponse({
      ok: true,
      data: {
        metric,
        unit,
        start_date: startDate,
        end_date: endDate,
        bucket,
        source,
        summaries_generated,
        points: paged,
        limit,
        offset,
        count: paged.length,
        total_count: totalBeforePaging,
        has_more: offset + limit < totalBeforePaging,
      },
    });
  } catch (err) {
    return errorResponse("Trend retrieval failed", "DATABASE_ERROR", { message: err instanceof Error ? err.message : String(err) }, 500);
  }
});
