import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

type JsonObject = Record<string, unknown>;

function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body, null, 2), {
    status,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-action-secret",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
    },
  });
}

function errorResponse(error: string, code: string, details: JsonObject = {}, status = 400) {
  return jsonResponse({ ok: false, error, code, details }, status);
}

function isIsoDate(value: unknown): value is string {
  return typeof value === "string" && /^\d{4}-\d{2}-\d{2}$/.test(value);
}

function getNumber(obj: JsonObject | null | undefined, key: string): number | null {
  if (!obj) return null;
  const value = obj[key];
  if (typeof value === "number" && Number.isFinite(value)) return value;
  if (typeof value === "string" && value.trim() !== "" && Number.isFinite(Number(value))) return Number(value);
  return null;
}

function getString(obj: JsonObject | null | undefined, key: string): string | null {
  if (!obj) return null;
  const value = obj[key];
  if (typeof value === "string" && value.trim() !== "") return value.trim();
  return null;
}

function pushUnique<T>(arr: T[], value: T | null | undefined) {
  if (value === null || value === undefined) return;
  if (!arr.includes(value)) arr.push(value);
}

function maxTrainingLoad(values: string[]): string | null {
  const rank: Record<string, number> = { rest: 0, light: 1, moderate: 2, hard: 3, very_hard: 4 };
  let best: string | null = null;
  let bestRank = -1;
  for (const raw of values) {
    const value = raw === "max_effort" ? "very_hard" : raw;
    if (rank[value] !== undefined && rank[value] > bestRank) {
      best = value;
      bestRank = rank[value];
    }
  }
  return best;
}

function summarizeDescriptions(prefix: string, descriptions: string[]): string | null {
  const clean = descriptions.map((d) => d.trim()).filter(Boolean);
  if (clean.length === 0) return null;
  return `${prefix}: ${clean.join(" | ")}`;
}

serve(async (req) => {
  if (req.method === "OPTIONS") return jsonResponse({ ok: true });
  if (req.method !== "POST") return errorResponse("Method not allowed", "METHOD_NOT_ALLOWED", {}, 405);

  const expectedSecret = Deno.env.get("ACTION_API_SECRET");
  if (!expectedSecret) return errorResponse("Server is missing ACTION_API_SECRET", "SERVER_CONFIG_ERROR", {}, 500);

  const actionSecretHeader = req.headers.get("X-Action-Secret") ?? req.headers.get("x-action-secret") ?? "";
  const authHeader = req.headers.get("Authorization") ?? "";
  const bearerSecret = authHeader.replace(/^Bearer\s+/i, "").trim();
  const providedSecret = actionSecretHeader.trim() || bearerSecret;

  if (!providedSecret || providedSecret !== expectedSecret) {
    return errorResponse("Unauthorized", "UNAUTHORIZED", {}, 401);
  }

  let body: JsonObject;
  try {
    body = await req.json();
  } catch (_err) {
    return errorResponse("Invalid JSON body", "INVALID_JSON");
  }

  const date = body.date;
  const generateIfMissing = body.generate_if_missing !== false;

  if (!isIsoDate(date)) {
    return errorResponse("date must be an ISO date string YYYY-MM-DD", "INVALID_DATE", { field: "date" });
  }

  if (typeof body.generate_if_missing !== "undefined" && typeof body.generate_if_missing !== "boolean") {
    return errorResponse("generate_if_missing must be boolean if provided", "VALIDATION_ERROR", { field: "generate_if_missing" });
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const serviceRoleKey = Deno.env.get("SERVICE_ROLE_KEY");
  if (!supabaseUrl || !serviceRoleKey) {
    return errorResponse("Server is missing Supabase configuration", "SERVER_CONFIG_ERROR", {}, 500);
  }

  const supabase = createClient(supabaseUrl, serviceRoleKey, { auth: { persistSession: false } });

  if (!generateIfMissing) {
    const { data: existing, error: existingError } = await supabase
      .from("daily_summaries")
      .select("*")
      .eq("summary_date", date)
      .maybeSingle();

    if (existingError) {
      return errorResponse("Database error while reading daily summary", "DATABASE_ERROR", { message: existingError.message }, 500);
    }

    return jsonResponse({ ok: true, data: { summary: existing ?? null, generated: false, stored: Boolean(existing) } });
  }

  const { data: events, error: eventError } = await supabase
    .from("fitness_events")
    .select("id, log_entry_id, occurred_date, occurred_time, event_type, title, description, source_text_span, facts, estimates, interpretations, extraction_confidence, estimate_confidence, needs_review, created_at, updated_at")
    .eq("occurred_date", date)
    .order("occurred_time", { ascending: true, nullsFirst: true })
    .order("created_at", { ascending: true });

  if (eventError) {
    return errorResponse("Database error while reading fitness events", "DATABASE_ERROR", { message: eventError.message }, 500);
  }

  const rows = events ?? [];
  const sourceLogEntryIds: string[] = [];
  const sourceFitnessEventIds: string[] = [];

  let bodyweightValue: number | null = null;
  let bodyweightUnit: string | null = null;

  let caloriesLow = 0;
  let caloriesHigh = 0;
  let hasCalories = false;

  let proteinLow = 0;
  let proteinHigh = 0;
  let hasProtein = false;

  let workoutCount = 0;
  const workoutDescriptions: string[] = [];
  const trainingLoadCandidates: string[] = [];
  const recoveryDescriptions: string[] = [];
  const sleepDescriptions: string[] = [];
  const symptomDescriptions: string[] = [];
  const flags: string[] = [];
  let needsReview = false;

  for (const event of rows) {
    pushUnique(sourceFitnessEventIds, event.id);
    pushUnique(sourceLogEntryIds, event.log_entry_id);

    const facts = (event.facts ?? {}) as JsonObject;
    const estimates = (event.estimates ?? {}) as JsonObject;

    if (event.needs_review) {
      needsReview = true;
      pushUnique(flags, "needs_review");
    }

    const calLow = getNumber(estimates, "calories_low");
    const calHigh = getNumber(estimates, "calories_high");
    if (calLow !== null || calHigh !== null) {
      hasCalories = true;
      caloriesLow += calLow ?? calHigh ?? 0;
      caloriesHigh += calHigh ?? calLow ?? 0;
    }

    const protLow = getNumber(estimates, "protein_g_low");
    const protHigh = getNumber(estimates, "protein_g_high");
    if (protLow !== null || protHigh !== null) {
      hasProtein = true;
      proteinLow += protLow ?? protHigh ?? 0;
      proteinHigh += protHigh ?? protLow ?? 0;
    }

    if (event.event_type === "weigh_in") {
      const weight = getNumber(facts, "weight_value");
      const unit = getString(facts, "weight_unit");
      if (weight !== null) {
        bodyweightValue = weight;
        bodyweightUnit = unit ?? "lb";
      }
    }

    if (event.event_type === "workout") {
      workoutCount += 1;
      workoutDescriptions.push(event.description);
      const estimatedLoad = getString(estimates, "training_load");
      const intensity = getString(facts, "intensity_reported");
      if (estimatedLoad) trainingLoadCandidates.push(estimatedLoad);
      if (intensity) trainingLoadCandidates.push(intensity);
    }

    if (event.event_type === "recovery") {
      recoveryDescriptions.push(event.description);
      const energy = getString(facts, "energy_level");
      const hunger = getString(facts, "hunger_level");
      const fatigue = getString(facts, "fatigue_level");
      const soreness = getString(facts, "soreness_level");
      if (energy === "low" || energy === "very_low") pushUnique(flags, "low_energy");
      if (hunger === "high" || hunger === "very_high") pushUnique(flags, "high_hunger");
      if (fatigue === "high" || fatigue === "very_high") pushUnique(flags, "fatigue");
      if (soreness === "high" || soreness === "very_high") pushUnique(flags, "high_soreness");
    }

    if (event.event_type === "sleep") {
      sleepDescriptions.push(event.description);
      const sleepQuality = getString(facts, "sleep_quality");
      if (sleepQuality === "poor") pushUnique(flags, "poor_sleep");
    }

    if (event.event_type === "alcohol") pushUnique(flags, "alcohol");
    if (event.event_type === "social_event") pushUnique(flags, "social_event");

    if (event.event_type === "symptom") {
      symptomDescriptions.push(event.description);
      pushUnique(flags, "symptom");
    }
  }

  const trainingLoad = maxTrainingLoad(trainingLoadCandidates);
  if (trainingLoad === "hard") pushUnique(flags, "hard_training_day");
  if (trainingLoad === "very_hard") pushUnique(flags, "very_hard_training_day");

  const symptomSummary = summarizeDescriptions("Symptoms", symptomDescriptions);
  if (symptomSummary) pushUnique(flags, "symptom_reported");

  const summary = {
    summary_date: date,
    bodyweight_value: bodyweightValue,
    bodyweight_unit: bodyweightUnit,
    calories_low: hasCalories ? Math.round(caloriesLow) : null,
    calories_high: hasCalories ? Math.round(caloriesHigh) : null,
    protein_g_low: hasProtein ? Math.round(proteinLow) : null,
    protein_g_high: hasProtein ? Math.round(proteinHigh) : null,
    workout_count: workoutCount,
    workout_summary: summarizeDescriptions("Workouts", workoutDescriptions),
    training_load: trainingLoad,
    recovery_summary: summarizeDescriptions("Recovery", recoveryDescriptions),
    sleep_summary: summarizeDescriptions("Sleep", sleepDescriptions),
    coach_summary: null,
    flags,
    source_log_entry_ids: sourceLogEntryIds,
    source_fitness_event_ids: sourceFitnessEventIds,
    generated_by: "edge_function_v0.1",
    needs_review: needsReview,
  };

  const { data: upserted, error: upsertError } = await supabase
    .from("daily_summaries")
    .upsert(summary, { onConflict: "summary_date" })
    .select("*")
    .single();

  if (upsertError) {
    return errorResponse("Database error while upserting daily summary", "DATABASE_ERROR", { message: upsertError.message }, 500);
  }

  return jsonResponse({ ok: true, data: { summary: upserted, generated: true, stored: true, event_count: rows.length } });
});
