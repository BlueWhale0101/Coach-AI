// supabase/functions/get-logs/index.ts
// Fitness Logging & Analysis System — get-logs v0.1
// Retrieves log_entries and their child fitness_events for a date range.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

type ErrorDetails = Record<string, unknown>;

const ALLOWED_EVENT_TYPES = new Set([
  "meal",
  "workout",
  "weigh_in",
  "recovery",
  "sleep",
  "note",
  "social_event",
  "alcohol",
  "symptom",
]);

function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body, null, 2), {
    status,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-action-secret",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
    },
  });
}

function errorResponse(
  error: string,
  code: string,
  details: ErrorDetails = {},
  status = 400,
): Response {
  return jsonResponse({ ok: false, error, code, details }, status);
}

function isIsoDate(value: unknown): value is string {
  return typeof value === "string" && /^\d{4}-\d{2}-\d{2}$/.test(value);
}

function isBooleanOrUndefined(value: unknown): value is boolean | undefined {
  return typeof value === "undefined" || typeof value === "boolean";
}

function parseLimit(value: unknown): number {
  if (typeof value === "undefined" || value === null) return 100;
  const n = Number(value);
  if (!Number.isInteger(n) || n < 1) return NaN;
  return Math.min(n, 500);
}

function parseOffset(value: unknown): number {
  if (typeof value === "undefined" || value === null) return 0;
  const n = Number(value);
  if (!Number.isInteger(n) || n < 0) return NaN;
  return n;
}

async function authenticate(req: Request): Promise<Response | null> {
  const expectedSecret = Deno.env.get("ACTION_API_SECRET");
  if (!expectedSecret) {
    return errorResponse(
      "Server is missing ACTION_API_SECRET",
      "SERVER_CONFIG_ERROR",
      {},
      500,
    );
  }

  // Prefer custom header because Supabase Dashboard / clients may inject Authorization JWTs.
  const actionSecretHeader =
    req.headers.get("X-Action-Secret") ??
    req.headers.get("x-action-secret") ??
    "";

  const authHeader = req.headers.get("Authorization") ?? "";
  const bearerSecret = authHeader.replace(/^Bearer\s+/i, "").trim();

  const providedSecret = actionSecretHeader.trim() || bearerSecret;

  if (!providedSecret || providedSecret !== expectedSecret) {
    return errorResponse("Unauthorized", "UNAUTHORIZED", {}, 401);
  }

  return null;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return jsonResponse({ ok: true });
  }

  if (req.method !== "POST") {
    return errorResponse("Method not allowed", "METHOD_NOT_ALLOWED", {}, 405);
  }

  const authError = await authenticate(req);
  if (authError) return authError;

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch (_err) {
    return errorResponse("Invalid JSON body", "INVALID_JSON", {}, 400);
  }

  const startDate = body.start_date;
  const endDate = body.end_date;
  const eventType = body.event_type;
  const includeRaw = typeof body.include_raw === "undefined" ? true : body.include_raw;
  const includeEvents = typeof body.include_events === "undefined" ? true : body.include_events;
  const limit = parseLimit(body.limit);
  const offset = parseOffset(body.offset);

  if (!isIsoDate(startDate)) {
    return errorResponse("start_date must be YYYY-MM-DD", "INVALID_DATE", { field: "start_date" }, 400);
  }

  if (!isIsoDate(endDate)) {
    return errorResponse("end_date must be YYYY-MM-DD", "INVALID_DATE", { field: "end_date" }, 400);
  }

  if (String(endDate) < String(startDate)) {
    return errorResponse("end_date must be greater than or equal to start_date", "VALIDATION_ERROR", {}, 400);
  }

  if (typeof eventType !== "undefined" && eventType !== null) {
    if (typeof eventType !== "string" || !ALLOWED_EVENT_TYPES.has(eventType)) {
      return errorResponse("Invalid event_type", "INVALID_EVENT_TYPE", {
        event_type: eventType,
        allowed_event_types: Array.from(ALLOWED_EVENT_TYPES),
      }, 400);
    }
  }

  if (!isBooleanOrUndefined(includeRaw)) {
    return errorResponse("include_raw must be boolean", "VALIDATION_ERROR", { field: "include_raw" }, 400);
  }

  if (!isBooleanOrUndefined(includeEvents)) {
    return errorResponse("include_events must be boolean", "VALIDATION_ERROR", { field: "include_events" }, 400);
  }

  if (Number.isNaN(limit)) {
    return errorResponse("limit must be an integer between 1 and 500", "VALIDATION_ERROR", { field: "limit" }, 400);
  }

  if (Number.isNaN(offset)) {
    return errorResponse("offset must be an integer greater than or equal to 0", "VALIDATION_ERROR", { field: "offset" }, 400);
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const serviceRoleKey = Deno.env.get("SERVICE_ROLE_KEY");

  if (!supabaseUrl || !serviceRoleKey) {
    return errorResponse("Server is missing Supabase configuration", "SERVER_CONFIG_ERROR", {}, 500);
  }

  const supabase = createClient(supabaseUrl, serviceRoleKey, {
    auth: { persistSession: false },
  });

  try {
    // Fetch one extra row to calculate has_more while returning at most limit rows.
    const from = offset;
    const to = offset + limit;

    let logQuery = supabase
      .from("log_entries")
      .select("id, occurred_date, occurred_time, raw_text, source, extraction_status, extraction_confidence, needs_review, created_at, updated_at")
      .gte("occurred_date", startDate)
      .lte("occurred_date", endDate)
      .order("occurred_date", { ascending: true })
      .order("occurred_time", { ascending: true, nullsFirst: true })
      .order("created_at", { ascending: true });

    if (includeEvents && typeof eventType === "string") {
      // Filter parent logs to only those that have at least one matching event.
      const { data: matchingEvents, error: matchingError } = await supabase
        .from("fitness_events")
        .select("log_entry_id")
        .eq("event_type", eventType)
        .gte("occurred_date", startDate)
        .lte("occurred_date", endDate);

      if (matchingError) {
        return errorResponse("Database error while filtering events", "DATABASE_ERROR", { message: matchingError.message }, 500);
      }

      const logIds = Array.from(new Set((matchingEvents ?? []).map((e) => e.log_entry_id)));
      if (logIds.length === 0) {
        return jsonResponse({
          ok: true,
          data: {
            logs: [],
            limit,
            offset,
            count: 0,
            has_more: false,
          },
        });
      }

      logQuery = logQuery.in("id", logIds);
    }

    const { data: logRowsRaw, error: logError } = await logQuery.range(from, to);

    if (logError) {
      return errorResponse("Database error while fetching logs", "DATABASE_ERROR", { message: logError.message }, 500);
    }

    const logRows = logRowsRaw ?? [];
    const hasMore = logRows.length > limit;
    const returnedLogs = hasMore ? logRows.slice(0, limit) : logRows;
    const logIds = returnedLogs.map((row) => row.id);

    let eventsByLogId = new Map<string, unknown[]>();

    if (includeEvents && logIds.length > 0) {
      let eventQuery = supabase
        .from("fitness_events")
        .select("id, log_entry_id, occurred_date, occurred_time, event_type, title, description, source_text_span, facts, estimates, interpretations, extraction_confidence, estimate_confidence, needs_review, created_at, updated_at")
        .in("log_entry_id", logIds)
        .order("occurred_date", { ascending: true })
        .order("occurred_time", { ascending: true, nullsFirst: true })
        .order("created_at", { ascending: true });

      if (typeof eventType === "string") {
        eventQuery = eventQuery.eq("event_type", eventType);
      }

      const { data: eventRows, error: eventError } = await eventQuery;

      if (eventError) {
        return errorResponse("Database error while fetching events", "DATABASE_ERROR", { message: eventError.message }, 500);
      }

      eventsByLogId = new Map<string, unknown[]>();
      for (const event of eventRows ?? []) {
        const list = eventsByLogId.get(event.log_entry_id) ?? [];
        list.push({
          event_id: event.id,
          event_type: event.event_type,
          title: event.title,
          description: event.description,
          source_text_span: event.source_text_span,
          facts: event.facts,
          estimates: event.estimates,
          interpretations: event.interpretations,
          extraction_confidence: event.extraction_confidence,
          estimate_confidence: event.estimate_confidence,
          needs_review: event.needs_review,
          occurred_date: event.occurred_date,
          occurred_time: event.occurred_time,
          created_at: event.created_at,
          updated_at: event.updated_at,
        });
        eventsByLogId.set(event.log_entry_id, list);
      }
    }

    const logs = returnedLogs.map((row) => {
      const entry: Record<string, unknown> = {
        log_entry_id: row.id,
        occurred_date: row.occurred_date,
        occurred_time: row.occurred_time,
        source: row.source,
        extraction_status: row.extraction_status,
        extraction_confidence: row.extraction_confidence,
        needs_review: row.needs_review,
        created_at: row.created_at,
        updated_at: row.updated_at,
      };

      if (includeRaw) entry.raw_text = row.raw_text;
      if (includeEvents) entry.events = eventsByLogId.get(row.id) ?? [];

      return entry;
    });

    return jsonResponse({
      ok: true,
      data: {
        logs,
        limit,
        offset,
        count: logs.length,
        has_more: hasMore,
      },
    });
  } catch (err) {
    return errorResponse("Unexpected server error", "DATABASE_ERROR", {
      message: err instanceof Error ? err.message : String(err),
    }, 500);
  }
});
