import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

type JsonObject = Record<string, unknown>;

const ALLOWED_SOURCES = ["gpt_action", "chat_backfill", "web_admin", "manual"] as const;

const ALLOWED_EVENT_TYPES = [
  "meal",
  "workout",
  "weigh_in",
  "recovery",
  "sleep",
  "note",
  "social_event",
  "alcohol",
  "symptom",
] as const;

function corsHeaders() {
  return {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-action-secret",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
  };
}

function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body, null, 2), {
    status,
    headers: corsHeaders(),
  });
}

function errorResponse(error: string, code: string, details: JsonObject = {}, status = 400) {
  return jsonResponse({ ok: false, error, code, details }, status);
}

function isPlainObject(value: unknown): value is JsonObject {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function isIsoDate(value: unknown): value is string {
  return typeof value === "string" && /^\d{4}-\d{2}-\d{2}$/.test(value);
}

function isTimeOrNull(value: unknown): value is string | null | undefined {
  return value === null || typeof value === "undefined" || (typeof value === "string" && /^\d{2}:\d{2}$/.test(value));
}

function isAllowed(value: unknown, allowed: readonly string[]): value is string {
  return typeof value === "string" && allowed.includes(value);
}

function isConfidence(value: unknown): boolean {
  return value === null || typeof value === "undefined" || (typeof value === "number" && Number.isFinite(value) && value >= 0 && value <= 1);
}

function validateEvent(event: unknown, index: number): string | null {
  if (!isPlainObject(event)) return `events[${index}] must be an object`;

  if (!isAllowed(event.event_type, ALLOWED_EVENT_TYPES)) {
    return `events[${index}].event_type must be one of: ${ALLOWED_EVENT_TYPES.join(", ")}`;
  }

  if (typeof event.description !== "string" || event.description.trim() === "") {
    return `events[${index}].description is required`;
  }

  if (!isPlainObject(event.facts)) {
    return `events[${index}].facts must be an object`;
  }

  if (!isPlainObject(event.estimates)) {
    return `events[${index}].estimates must be an object`;
  }

  if (!isPlainObject(event.interpretations)) {
    return `events[${index}].interpretations must be an object`;
  }

  if (!isTimeOrNull(event.occurred_time)) {
    return `events[${index}].occurred_time must be null or HH:MM`;
  }

  if (!isConfidence(event.extraction_confidence)) {
    return `events[${index}].extraction_confidence must be null or 0..1`;
  }

  if (!isConfidence(event.estimate_confidence)) {
    return `events[${index}].estimate_confidence must be null or 0..1`;
  }

  if (typeof event.needs_review !== "undefined" && typeof event.needs_review !== "boolean") {
    return `events[${index}].needs_review must be boolean`;
  }

  return null;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return jsonResponse({ ok: true });
  }

  if (req.method !== "POST") {
    return errorResponse("Method not allowed", "METHOD_NOT_ALLOWED", {}, 405);
  }

  const expectedSecret = Deno.env.get("ACTION_API_SECRET");
  if (!expectedSecret) {
    return errorResponse("Server is missing ACTION_API_SECRET", "SERVER_CONFIG_ERROR", {}, 500);
  }

  const actionSecretHeader =
    req.headers.get("X-Action-Secret") ??
    req.headers.get("x-action-secret") ??
    "";

  const authHeader = req.headers.get("Authorization") ?? "";
  const bearerSecret = authHeader.replace(/^Bearer\s+/i, "").trim();

  const providedSecret = actionSecretHeader.trim() || bearerSecret;

  if (!providedSecret || providedSecret !== expectedSecret) {
    return errorResponse("Unauthorized", "UNAUTHORIZED", {}, 401);
  }

  let body: JsonObject;
  try {
    body = await req.json();
  } catch (_err) {
    return errorResponse("Invalid JSON body", "INVALID_JSON");
  }

  const occurredDate = body.occurred_date;
  const occurredTime = body.occurred_time;
  const rawText = body.raw_text;
  const source = body.source;
  const events = body.events;

  if (!isIsoDate(occurredDate)) {
    return errorResponse("occurred_date must be an ISO date string YYYY-MM-DD", "INVALID_DATE", { field: "occurred_date" });
  }

  if (!isTimeOrNull(occurredTime)) {
    return errorResponse("occurred_time must be null or HH:MM", "INVALID_TIME", { field: "occurred_time" });
  }

  if (typeof rawText !== "string" || rawText.trim() === "") {
    return errorResponse("raw_text is required", "MISSING_REQUIRED_FIELD", { field: "raw_text" });
  }

  if (!isAllowed(source, ALLOWED_SOURCES)) {
    return errorResponse("Invalid source", "INVALID_SOURCE", { source, allowed_sources: ALLOWED_SOURCES });
  }

  if (!Array.isArray(events)) {
    return errorResponse("events must be an array", "VALIDATION_ERROR", { field: "events" });
  }

  for (let i = 0; i < events.length; i++) {
    const eventError = validateEvent(events[i], i);
    if (eventError) {
      return errorResponse(eventError, "VALIDATION_ERROR", { index: i });
    }
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const serviceRoleKey = Deno.env.get("SERVICE_ROLE_KEY");

  if (!supabaseUrl || !serviceRoleKey) {
    return errorResponse("Server is missing Supabase configuration", "SERVER_CONFIG_ERROR", {}, 500);
  }

  const supabase = createClient(supabaseUrl, serviceRoleKey, {
    auth: { persistSession: false },
  });

  const logNeedsReview = events.some((event: JsonObject) => event.needs_review === true);
  const confidenceValues = events
    .map((event: JsonObject) => event.extraction_confidence)
    .filter((value: unknown): value is number => typeof value === "number" && Number.isFinite(value));
  const logExtractionConfidence =
    confidenceValues.length > 0
      ? Math.min(...confidenceValues)
      : null;

  const { data: logEntry, error: logError } = await supabase
    .from("log_entries")
    .insert({
      occurred_date: occurredDate,
      occurred_time: occurredTime ?? null,
      raw_text: rawText,
      source,
      extraction_status: events.length > 0 ? "extracted" : "skipped",
      extraction_confidence: logExtractionConfidence,
      needs_review: logNeedsReview,
    })
    .select("id")
    .single();

  if (logError || !logEntry) {
    return errorResponse("Database error while inserting log entry", "DATABASE_ERROR", { message: logError?.message }, 500);
  }

  const eventRows = events.map((event: JsonObject) => ({
    log_entry_id: logEntry.id,
    event_type: event.event_type,
    title: event.title ?? null,
    description: event.description,
    occurred_date: occurredDate,
    occurred_time: event.occurred_time ?? occurredTime ?? null,
    source_text_span: event.source_text_span ?? null,
    facts: event.facts,
    estimates: event.estimates,
    interpretations: event.interpretations,
    extraction_confidence: event.extraction_confidence ?? null,
    estimate_confidence: event.estimate_confidence ?? null,
    needs_review: event.needs_review ?? false,
  }));

  let eventIds: string[] = [];

  if (eventRows.length > 0) {
    const { data: insertedEvents, error: eventError } = await supabase
      .from("fitness_events")
      .insert(eventRows)
      .select("id");

    if (eventError) {
      await supabase.from("log_entries").delete().eq("id", logEntry.id);
      return errorResponse("Database error while inserting fitness events", "DATABASE_ERROR", { message: eventError.message }, 500);
    }

    eventIds = (insertedEvents ?? []).map((event: { id: string }) => event.id);
  }

  return jsonResponse({
    ok: true,
    data: {
      log_entry_id: logEntry.id,
      event_ids: eventIds,
      events_created: eventIds.length,
      needs_review: logNeedsReview,
    },
    log_entry_id: logEntry.id,
    event_ids: eventIds,
    events_created: eventIds.length,
    needs_review: logNeedsReview,
  });
});
