// supabase/functions/search-events/index.ts
// Fitness Logging & Analysis System — search-events v0.1
// Searches fitness_events and parent log_entries by keyword, type, date range, and review state.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

type ErrorDetails = Record<string, unknown>;

const ALLOWED_EVENT_TYPES = new Set([
  "meal",
  "workout",
  "weigh_in",
  "recovery",
  "sleep",
  "note",
  "social_event",
  "alcohol",
  "symptom",
]);

function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body, null, 2), {
    status,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-action-secret",
      "Access-Control-Allow-Methods": "POST, OPTIONS",
    },
  });
}

function errorResponse(
  error: string,
  code: string,
  details: ErrorDetails = {},
  status = 400,
): Response {
  return jsonResponse({ ok: false, error, code, details }, status);
}

function isIsoDate(value: unknown): value is string {
  return typeof value === "string" && /^\d{4}-\d{2}-\d{2}$/.test(value);
}

function parseLimit(value: unknown): number {
  if (typeof value === "undefined" || value === null) return 50;
  const n = Number(value);
  if (!Number.isInteger(n) || n < 1) return NaN;
  return Math.min(n, 500);
}

function parseOffset(value: unknown): number {
  if (typeof value === "undefined" || value === null) return 0;
  const n = Number(value);
  if (!Number.isInteger(n) || n < 0) return NaN;
  return n;
}

async function authenticate(req: Request): Promise<Response | null> {
  const expectedSecret = Deno.env.get("ACTION_API_SECRET");
  if (!expectedSecret) {
    return errorResponse(
      "Server is missing ACTION_API_SECRET",
      "SERVER_CONFIG_ERROR",
      {},
      500,
    );
  }

  // Prefer custom header because Supabase Dashboard / clients may inject Authorization JWTs.
  const actionSecretHeader =
    req.headers.get("X-Action-Secret") ??
    req.headers.get("x-action-secret") ??
    "";

  const authHeader = req.headers.get("Authorization") ?? "";
  const bearerSecret = authHeader.replace(/^Bearer\s+/i, "").trim();

  const providedSecret = actionSecretHeader.trim() || bearerSecret;

  if (!providedSecret || providedSecret !== expectedSecret) {
    return errorResponse("Unauthorized", "UNAUTHORIZED", {}, 401);
  }

  return null;
}

function stringifyForSearch(value: unknown): string {
  if (value === null || typeof value === "undefined") return "";
  if (typeof value === "string") return value;
  try {
    return JSON.stringify(value);
  } catch (_err) {
    return String(value);
  }
}

function includesQuery(haystack: unknown[], query: string): boolean {
  const needle = query.trim().toLowerCase();
  if (!needle) return true;
  return haystack.some((part) => stringifyForSearch(part).toLowerCase().includes(needle));
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return jsonResponse({ ok: true });
  }

  if (req.method !== "POST") {
    return errorResponse("Method not allowed", "METHOD_NOT_ALLOWED", {}, 405);
  }

  const authError = await authenticate(req);
  if (authError) return authError;

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch (_err) {
    return errorResponse("Invalid JSON body", "INVALID_JSON", {}, 400);
  }

  const query = body.query;
  const eventType = body.event_type;
  const startDate = body.start_date;
  const endDate = body.end_date;
  const needsReview = body.needs_review;
  const limit = parseLimit(body.limit);
  const offset = parseOffset(body.offset);

  const hasQuery = typeof query === "string" && query.trim().length > 0;
  const hasEventType = typeof eventType === "string" && eventType.trim().length > 0;
  const hasStartDate = typeof startDate !== "undefined" && startDate !== null;
  const hasEndDate = typeof endDate !== "undefined" && endDate !== null;
  const hasNeedsReview = typeof needsReview !== "undefined" && needsReview !== null;

  if (!hasQuery && !hasEventType && !hasStartDate && !hasEndDate && !hasNeedsReview) {
    return errorResponse(
      "At least one search constraint is required",
      "NO_SEARCH_CONSTRAINT",
      {},
      400,
    );
  }

  if (hasQuery && typeof query !== "string") {
    return errorResponse("query must be a string", "VALIDATION_ERROR", { field: "query" }, 400);
  }

  if (hasEventType) {
    if (typeof eventType !== "string" || !ALLOWED_EVENT_TYPES.has(eventType)) {
      return errorResponse("Invalid event_type", "INVALID_EVENT_TYPE", {
        event_type: eventType,
        allowed_event_types: Array.from(ALLOWED_EVENT_TYPES),
      }, 400);
    }
  }

  if (hasStartDate && !isIsoDate(startDate)) {
    return errorResponse("start_date must be YYYY-MM-DD", "INVALID_DATE", { field: "start_date" }, 400);
  }

  if (hasEndDate && !isIsoDate(endDate)) {
    return errorResponse("end_date must be YYYY-MM-DD", "INVALID_DATE", { field: "end_date" }, 400);
  }

  if (hasStartDate && hasEndDate && String(endDate) < String(startDate)) {
    return errorResponse("end_date must be greater than or equal to start_date", "VALIDATION_ERROR", {}, 400);
  }

  if (hasNeedsReview && typeof needsReview !== "boolean") {
    return errorResponse("needs_review must be boolean", "VALIDATION_ERROR", { field: "needs_review" }, 400);
  }

  if (Number.isNaN(limit)) {
    return errorResponse("limit must be an integer between 1 and 500", "VALIDATION_ERROR", { field: "limit" }, 400);
  }

  if (Number.isNaN(offset)) {
    return errorResponse("offset must be an integer greater than or equal to 0", "VALIDATION_ERROR", { field: "offset" }, 400);
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const serviceRoleKey = Deno.env.get("SERVICE_ROLE_KEY");

  if (!supabaseUrl || !serviceRoleKey) {
    return errorResponse("Server is missing Supabase configuration", "SERVER_CONFIG_ERROR", {}, 500);
  }

  const supabase = createClient(supabaseUrl, serviceRoleKey, {
    auth: { persistSession: false },
  });

  try {
    // V0.1 strategy: fetch a bounded candidate set with structural filters, then
    // perform broad text matching in code over description, spans, JSONB, and parent raw_text.
    // This is intentionally simple and reliable for the early one-user dataset.
    const candidateLimit = Math.min(Math.max(limit + offset + 50, 250), 2000);

    let eventQuery = supabase
      .from("fitness_events")
      .select("id, log_entry_id, occurred_date, occurred_time, event_type, title, description, source_text_span, facts, estimates, interpretations, extraction_confidence, estimate_confidence, needs_review, created_at, updated_at")
      .order("occurred_date", { ascending: false })
      .order("occurred_time", { ascending: false, nullsFirst: false })
      .order("created_at", { ascending: false })
      .limit(candidateLimit);

    if (hasEventType && typeof eventType === "string") {
      eventQuery = eventQuery.eq("event_type", eventType);
    }

    if (hasStartDate && typeof startDate === "string") {
      eventQuery = eventQuery.gte("occurred_date", startDate);
    }

    if (hasEndDate && typeof endDate === "string") {
      eventQuery = eventQuery.lte("occurred_date", endDate);
    }

    if (hasNeedsReview && typeof needsReview === "boolean") {
      eventQuery = eventQuery.eq("needs_review", needsReview);
    }

    const { data: eventRowsRaw, error: eventError } = await eventQuery;

    if (eventError) {
      return errorResponse("Database error while fetching events", "DATABASE_ERROR", { message: eventError.message }, 500);
    }

    const eventRows = eventRowsRaw ?? [];
    const logIds = Array.from(new Set(eventRows.map((event) => event.log_entry_id).filter(Boolean)));

    const rawTextByLogId = new Map<string, string>();
    const logMetaById = new Map<string, Record<string, unknown>>();

    if (logIds.length > 0) {
      const { data: logRows, error: logError } = await supabase
        .from("log_entries")
        .select("id, occurred_date, occurred_time, raw_text, source, extraction_status, extraction_confidence, needs_review, created_at, updated_at")
        .in("id", logIds);

      if (logError) {
        return errorResponse("Database error while fetching parent logs", "DATABASE_ERROR", { message: logError.message }, 500);
      }

      for (const log of logRows ?? []) {
        rawTextByLogId.set(log.id, log.raw_text ?? "");
        logMetaById.set(log.id, log);
      }
    }

    const normalizedQuery = hasQuery && typeof query === "string" ? query.trim() : "";

    const filtered = eventRows.filter((event) => {
      if (!normalizedQuery) return true;

      const rawText = rawTextByLogId.get(event.log_entry_id) ?? "";
      return includesQuery([
        rawText,
        event.title,
        event.description,
        event.source_text_span,
        event.event_type,
        event.facts,
        event.estimates,
        event.interpretations,
      ], normalizedQuery);
    });

    const paged = filtered.slice(offset, offset + limit);
    const hasMore = filtered.length > offset + limit || eventRows.length === candidateLimit;

    const results = paged.map((event) => {
      const rawText = rawTextByLogId.get(event.log_entry_id) ?? null;
      const logMeta = logMetaById.get(event.log_entry_id) ?? {};
      return {
        event_id: event.id,
        log_entry_id: event.log_entry_id,
        occurred_date: event.occurred_date,
        occurred_time: event.occurred_time,
        event_type: event.event_type,
        title: event.title,
        description: event.description,
        source_text_span: event.source_text_span,
        facts: event.facts,
        estimates: event.estimates,
        interpretations: event.interpretations,
        extraction_confidence: event.extraction_confidence,
        estimate_confidence: event.estimate_confidence,
        needs_review: event.needs_review,
        created_at: event.created_at,
        updated_at: event.updated_at,
        raw_text: rawText,
        log_entry: {
          occurred_date: logMeta.occurred_date ?? null,
          occurred_time: logMeta.occurred_time ?? null,
          source: logMeta.source ?? null,
          extraction_status: logMeta.extraction_status ?? null,
          extraction_confidence: logMeta.extraction_confidence ?? null,
          needs_review: logMeta.needs_review ?? null,
          created_at: logMeta.created_at ?? null,
          updated_at: logMeta.updated_at ?? null,
        },
      };
    });

    return jsonResponse({
      ok: true,
      data: {
        results,
        limit,
        offset,
        count: results.length,
        has_more: hasMore,
        search_strategy: "bounded_candidate_scan_v0.1",
      },
    });
  } catch (err) {
    return errorResponse("Unexpected server error", "DATABASE_ERROR", {
      message: err instanceof Error ? err.message : String(err),
    }, 500);
  }
});
